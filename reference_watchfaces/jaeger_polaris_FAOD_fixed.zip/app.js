/* __ZOS_UNIVERSAL_COMPAT_SHIM__ (Zepp OS 1.0 / 2.0 / 3.x Bridge) */
(function() {
  try {
    var __g__ = typeof globalThis !== 'undefined' ? globalThis : (typeof self !== 'undefined' ? self : (typeof global !== 'undefined' ? global : Function('return this')()));
    if (!__g__) return;
    __g__.hmUI = __g__.hmUI || {};
    __g__.hmUI.show_level = __g__.hmUI.show_level || { ALL: 1, ONLY_NORMAL: 1, ONLY_AOD: 1, ONAL_NORAML: 1 };
    __g__.hmUI.vis_mode = __g__.hmUI.vis_mode || { ALL: 0, ONLY_NORMAL: 0, ONLY_AOD: 0 };
    __g__.hmUI.widget = __g__.hmUI.widget || { IMG: 1, TEXT: 2, ARC: 3, FILL_RECT: 4, STROKE_RECT: 5, IMG_TIME: 6, TEXT_TIME: 7, IMG_NUMBER: 8, TIME_POINTER: 9, WIDGET_DELEGATE: 10, IMG_LEVEL: 11, IMG_PROGRESS: 12, CIRCLE: 13, IMG_STATUS: 14, IMG_WEEK: 15, IMG_DATE: 16, SPORT_DATA: 17, HISTOGRAM: 18, IMG_ANIM: 19, GROUP: 20 };
    __g__.hmUI.prop = __g__.hmUI.prop || { MORE: 1, ANGLE: 2, POS_X: 3, POS_Y: 4, CENTER_X: 5, CENTER_Y: 6, SRC: 7, TEXT: 8, VISIBLE: 9, ALPHA: 10, CURRENT_TYPE: 11, VALUE: 12 };
    __g__.hmSetting = __g__.hmSetting || { screen_type: { WATCHFACE: 0, AOD: 1, SETTINGS: 2 }, getScreenType: function() { return 0; } };
    __g__.hmSensor = __g__.hmSensor || { id: { TIME: 1, BATTERY: 2, STEP: 3, CALORIE: 4, HEART: 5, PAI: 6, DISTANCE: 7, STAND: 8, WEATHER: 9, SLEEP: 10 }, event: { CHANGE: 1, LAST: 2 }, createSensor: function() { return { get second() { return (new Date()).getSeconds(); }, get minute() { return (new Date()).getMinutes(); }, get hour() { return (new Date()).getHours(); }, addEventListener: function() {} }; } };
  } catch (__compatErr) {}
})();

try {
  (() => {
  
var __$$app$$__ = __$$hmAppManager$$__.currentApp;

/*
* Watch_Face_Editor tool v1.x
* Copyright © Huami. All Rights Reserved
*/
'use strict';

__$$app$$__.app = DeviceRuntimeCore.App({
    globalData: {},
    onCreate(options) {
    },
    onShow(options) {
    },
    onHide(options) {
    },
    onDestory(options) {
    },
    onError(error) {
    },
    onPageNotFound(obj) {
    },
    onUnhandledRejection(obj) {
    }
});
/*
* end js
*/

  })()
} catch(e) {
  console.log(e)
  /* todo */
}